SEASONAL HOURLY WEATHER FOR SCRIPTABLE
======================================
Contents:
  Seasonal_Hourly_Weather.js      Complete Scriptable widget script
  SeasonalWeatherArt/             96 locally stored background images
  README_Seasonal_Weather.txt     This guide

INSTALL ON YOUR IPHONE
1. Download Seasonal_Weather_Widget_Kit.zip into the Files app.
2. Tap the ZIP in Files to unzip it. You should see a folder containing this
   guide, the .js script, and a subfolder called SeasonalWeatherArt.
3. Open Seasonal_Hourly_Weather.js and copy its whole contents into a NEW script
   in Scriptable named "Seasonal Hourly Weather".
4. Run the script once inside Scriptable. When prompted, choose
   "Choose artwork folder". Files will open.
5. Select the extracted folder named SeasonalWeatherArt (NOT the parent kit
   folder). The script will copy the 96 backgrounds into its local storage.
6. Grant location access to Scriptable if prompted. The script previews the
   small widget. Confirm the current location, temperature and icons.
7. Edit your Home Screen and add a SMALL Scriptable widget. In the widget's
   settings, choose "Seasonal Hourly Weather".

WHAT CHANGES AUTOMATICALLY
- Uses GPS for your current location; NO hard-coded hometown fallback.
- Uses Open-Meteo for live current and hourly forecast information.
- Meteorological seasons for the location, including Southern Hemisphere.
- Weather conditions: sunny/clear, partly cloudy, cloudy, rain, heavy rain,
  thunderstorms, snow, fog, mixed/freezing rain when applicable.
- Solar phase: daytime, the +/-40 minute sunrise/sunset twilight window,
  and nighttime.
- Tap widget to launch Apple Weather via unofficial weather:// scheme.
  If Apple changes the scheme, use a Shortcut alternative.
- iOS controls widget refresh timing; the requested refresh is 30 minutes.

CUSTOMIZATION
At top of script SETTINGS:
  contentWidth: 138        Width of the centered content column (points).
  locationToTemp: 0        Gap between location and current temperature.
  tempToCondition: 5       Gap between current temperature and condition.
  conditionToForecast: 3  Gap between condition and the hourly cards.
  topPadding: 8           Top external margin.
  bottomPadding: 8        Bottom external margin.

Testing the artwork (only when running script inside Scriptable):
  testSeason: "fall", testCondition: "rain", testPhase: "day"
Set those values back to null for normal automatic behavior.

TROUBLESHOOTING
- If the image doesn't load, confirm you selected the folder containing the
  96 .jpg files. Run in Scriptable again to retry importing.
- If the location says "Location unavailable", enable Scriptable location
  access and run the script in the app. If your last GPS fix is up to 48 hours
  old, a tilde before the city name indicates approximate cached location.
- If the network is offline, recent same-area weather data may still display;
  after it expires, the widget displays "Weather unavailable".
- Keep the artwork folder in the downloaded ZIP only until the import works;
  after that Scriptable stores its own copy.
