# Seasonal Weather

A free small-format Scriptable widget for iPhone, with current-location forecasts and seasonal photographic backgrounds.

This repository includes:

- `index.html`, `styles.css`, `app.js`: a fully static landing page, interactive sample preview, and installation guide.
- `assets/backgrounds/`: 96 local seasonal weather backgrounds (4 seasons × 8 weather types × 3 light phases).
- `downloads/Seasonal_Hourly_Weather.js`: the widget script, including text shadows.
- `downloads/Seasonal_Weather_Widget_Kit.zip`: a complete install pack with the JavaScript, 96 backgrounds and mobile installation guide.
- `downloads/README_Seasonal_Weather.txt`: install instructions in text form.

## Publish to GitHub Pages

1. Create a public GitHub repository, for example `seasonal-weather`.
2. Upload the **contents** of this folder to the repository root, making sure `index.html` appears at the root. Upload all files including `assets` and `downloads`.
3. Go to repository **Settings → Pages**.
4. Under **Build and deployment**, choose **Deploy from a branch**. Choose `main` and `/(root)`, then save.
5. When GitHub finishes deploying, visit `https://YOUR-USERNAME.github.io/seasonal-weather/`.

No build step, Node installation, external JavaScript libraries, or hosting fees are needed for a public GitHub Pages repository.

## Test locally

You can open `index.html` to preview most of the page, but the **Copy full script** button requires a local HTTP server or a deployed HTTPS site. From this folder, run:

```bash
python3 -m http.server 8000
```

Then open `http://localhost:8000/` in your browser.

## Install widget on iPhone

1. Download the ZIP from the landing page.
2. Unzip it in iOS Files.
3. Create a script in Scriptable named `Seasonal Hourly Weather` and paste the full contents of `Seasonal_Hourly_Weather.js`.
4. Run the script inside Scriptable. Choose the unzipped `SeasonalWeatherArt` folder when prompted.
5. Grant Scriptable permission to access your location. Add a **small** Scriptable widget and select your script.

The page's preview uses **sample values** and **does not request location**. The installed widget calls Scriptable's `Location.current()` to request device coordinates, then sends the latitude and longitude to Open-Meteo for the forecast. Location and weather cache files stay on the device under Scriptable's local file directory. The app does not include an API key, token, email, account number, or hardcoded hometown.

## Technology, data, and attribution

- [Scriptable](https://scriptable.app/) runs the widget; this is an independent community project.
- Forecast data is provided by [Open-Meteo](https://open-meteo.com/). Attribution is required under [CC BY 4.0](https://creativecommons.org/licenses/by/4.0/). The Open-Meteo free API is for non-commercial use under its [terms](https://open-meteo.com/en/terms).
- Tap-to-open Apple Weather uses the unofficial `weather://` URL scheme and may vary by iOS version.
- iOS controls widget update timing, even if the widget requests a 30-minute refresh.

## Before publicly sharing

- Check that the images and installation experience work on your iPhone.
- Decide whether you want to keep the MIT license provided with the code, or select a different license for your artwork and code. Edit the project credit as desired.
- Open-Meteo's data license applies to the weather data; this repository does not include live Open-Meteo data.

## License

The code in this sample is offered under the MIT license (see `LICENSE`). The included illustration assets are part of this project kit. You, as the publisher, should review and confirm what license and redistribution permissions you want to grant for the artwork before publishing.
