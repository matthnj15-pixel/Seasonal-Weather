(function(){
  'use strict';
  const selection={season:'fall',condition:'sunny',phase:'day'};
  const seasonLabels={spring:'Spring',summer:'Summer',fall:'Autumn',winter:'Winter'};
  const conditionLabels={sunny:'Sunny',partly:'Partly Cloudy',cloudy:'Cloudy',rain:'Rain',heavy:'Heavy Rain',storm:'Thunderstorms',snow:'Snow',fog:'Foggy'};
  const icons={sunny:'☀',partly:'🌤',cloudy:'☁',rain:'🌧',heavy:'🌧',storm:'⛈',snow:'❄',fog:'≋'};
  const temps={spring:67,summer:84,fall:62,winter:28};
  const nightAdjustment={day:0,twilight:-4,night:-10};
  const conditionAdjustment={sunny:0,partly:-1,cloudy:-3,rain:-6,heavy:-8,storm:-4,snow:-12,fog:-7};
  const phaseLabels={day:'Day',twilight:'Twilight',night:'Night'};
  function iconFor(type,phase){return type==='sunny'&&phase==='night'?'☾':type==='partly'&&phase==='night'?'☁':icons[type]}
  function renderCard(prefix){
    const card=document.getElementById(prefix==='hero'?'hero-widget':'preview-widget');if(!card)return;
    const season=selection.season, condition=selection.condition,phase=selection.phase;
    card.style.backgroundImage=`url("assets/backgrounds/${season}_${condition}_${phase}.jpg")`;
    const temp=temps[season]+nightAdjustment[phase]+conditionAdjustment[condition];
    const tempEl=document.getElementById(prefix==='hero'?'hero-temp':'current-temp');tempEl.textContent=`${temp}°`;
    const name=condition==='sunny'&&phase==='night'?'Clear':conditionLabels[condition];
    document.getElementById(prefix==='hero'?'hero-condition':'condition-label').textContent=name;
    document.getElementById(prefix==='hero'?'hero-condition-icon':'condition-icon').textContent=iconFor(condition,phase);
    const grid=document.getElementById(prefix==='hero'?'hero-forecast':'forecast-grid');grid.replaceChildren();
    for(let i=0;i<3;i++){
      const time=['12 PM','1 PM','2 PM'][i];
      const cell=document.createElement('div');cell.className='forecast-hour';
      const label=document.createElement('div');label.className='time';label.textContent=time;
      const symbol=document.createElement('div');symbol.className='symbol';symbol.textContent=iconFor(condition,phase);
      const degrees=document.createElement('div');degrees.className='degrees';degrees.textContent=`${temp+i+2}°`;
      cell.append(label,symbol,degrees);grid.appendChild(cell);
    }
  }
  function render(){renderCard('hero');renderCard('demo');document.getElementById('preview-label').textContent=`${seasonLabels[selection.season]} · ${conditionLabels[selection.condition]} · ${phaseLabels[selection.phase]}`;for(const [name,property] of [['season','season'],['condition','condition'],['phase','phase']]){document.querySelectorAll(`[data-${name}]`).forEach(b=>{const active=b.dataset[name]===selection[property];b.classList.toggle('selected',active);b.setAttribute('aria-pressed',active?'true':'false')})}}
  for(const name of ['season','condition','phase']){document.querySelectorAll(`[data-${name}]`).forEach(b=>b.addEventListener('click',()=>{selection[name]=b.dataset[name];render()}))}
  document.querySelectorAll('[data-gallery-season]').forEach(b=>b.addEventListener('click',()=>{selection.season=b.dataset.gallerySeason;selection.condition='sunny';selection.phase='day';render();document.getElementById('explore').scrollIntoView({behavior:'smooth'})}));
  const copyButton=document.getElementById('copy-script');
  copyButton.addEventListener('click',async()=>{
    const status=document.getElementById('copy-status');status.textContent='';
    try{
      const response=await fetch('downloads/Seasonal_Hourly_Weather.js');if(!response.ok)throw new Error('Script download unavailable');
      const source=await response.text();
      if(navigator.clipboard && window.isSecureContext){await navigator.clipboard.writeText(source)}
      else{const field=document.createElement('textarea');field.value=source;field.style.position='fixed';field.style.opacity='0';document.body.appendChild(field);field.focus();field.select();const ok=document.execCommand('copy');field.remove();if(!ok)throw new Error('Clipboard permission was denied')}
      status.textContent='Copied! Paste the script into Scriptable.';copyButton.textContent='Copied ✓';setTimeout(()=>{copyButton.innerHTML='Copy full script <span aria-hidden="true">⧉</span>'},3000);
    }catch(err){status.textContent='Could not copy automatically. Use “JavaScript only” to open the file.'}
  });
  render();
})();
